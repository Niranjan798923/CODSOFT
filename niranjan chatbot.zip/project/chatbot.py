from datetime import datetime

def chatbot():
    while True:
        user_input = input("You: ").lower().strip()

        if not user_input:
            continue

        if user_input in ["hello", "hi", "hey"]:
            print("Niranjan Chatbot: Hello! How can I help you today?")
        
        elif "how are you" in user_input:
            print("Niranjan Chatbot: I'm doing great! Thanks for asking!")
        
        elif any(phrase in user_input for phrase in ["who are you", "what are you", "your name"]):
            print("Niranjan Chatbot: I'm Niranjan Chatbot, created to help answer your questions!")
        
        elif "weather" in user_input:
            print("Niranjan Chatbot: I'm sorry, I don't have access to real-time weather data. You might want to check a weather service for that information.")
        
        elif "time" in user_input:
            current_time = datetime.now().strftime("%H:%M:%S")
            print(f"Niranjan Chatbot: The current time is {current_time}")
        
        elif "help" in user_input:
            print("Niranjan Chatbot: I can help you with basic questions. Try asking me about greetings, time, weather, or my name!")
        
        elif user_input in ["bye", "goodbye", "exit"]:
            print("Niranjan Chatbot: Goodbye! Have a great day!")
            break
        
        elif "thank" in user_input:
            print("Niranjan Chatbot: You're welcome! Is there anything else I can help you with?")
        
        else:
            print("Niranjan Chatbot: I'm not sure how to respond to that. Could you try rephrasing your question?")

if __name__ == "__main__":
    chatbot()